#!/bin/bash
# ==============================================
#   ProjectOS — Quick Setup Script
# ==============================================

echo ""
echo "⚡  ProjectOS Setup"
echo "================================"

# 1. Create virtual environment
echo "→ Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# 2. Install dependencies
echo "→ Installing dependencies..."
pip install -r requirements.txt --quiet

# 3. Run migrations
echo "→ Running database migrations..."
python manage.py makemigrations projectapp
python manage.py migrate

# 4. Create superuser (optional - skip if exists)
echo ""
echo "→ Creating demo admin user (admin / admin123)..."
python manage.py shell -c "
from django.contrib.auth.models import User
from projectapp.models import Profile
if not User.objects.filter(username='admin').exists():
    u = User.objects.create_superuser('admin', 'admin@example.com', 'admin123')
    u.first_name = 'Admin'
    u.last_name = 'User'
    u.save()
    Profile.objects.get_or_create(user=u, defaults={'job_title': 'Administrator', 'bio': 'System administrator'})
    print('  Admin created: admin / admin123')
else:
    print('  Admin already exists')
"

# 5. Collect static files
echo "→ Collecting static files..."
python manage.py collectstatic --noinput --clear -v 0

echo ""
echo "✅  Setup complete!"
echo ""
echo "Run the server with:"
echo "   source venv/bin/activate"
echo "   python manage.py runserver"
echo ""
echo "Open: http://127.0.0.1:8000"
echo "Admin: http://127.0.0.1:8000/admin  (admin / admin123)"
echo ""
