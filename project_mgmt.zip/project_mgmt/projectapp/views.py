from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Q, Count
from django.http import JsonResponse
from .models import Profile, FriendRequest, Project, Task, Comment
from .forms import RegisterForm, ProfileForm, ProjectForm, TaskForm, CommentForm
from django.contrib.auth.forms import AuthenticationForm


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.create(user=user)
            login(request, user)
            messages.success(request, f'Welcome aboard, {user.first_name}! 🚀')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'Welcome back, {user.first_name or user.username}!')
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def dashboard(request):
    user = request.user
    my_projects = Project.objects.filter(
        Q(owner=user) | Q(members=user)
    ).distinct().order_by('-updated_at')[:6]

    my_tasks = Task.objects.filter(assigned_to=user).exclude(status='done').order_by('due_date')[:8]

    total_projects = Project.objects.filter(Q(owner=user) | Q(members=user)).distinct().count()
    active_projects = Project.objects.filter(Q(owner=user) | Q(members=user), status='active').distinct().count()
    total_tasks = Task.objects.filter(assigned_to=user).count()
    done_tasks = Task.objects.filter(assigned_to=user, status='done').count()
    pending_requests = FriendRequest.objects.filter(receiver=user, status='pending').count()

    context = {
        'my_projects': my_projects,
        'my_tasks': my_tasks,
        'total_projects': total_projects,
        'active_projects': active_projects,
        'total_tasks': total_tasks,
        'done_tasks': done_tasks,
        'pending_requests': pending_requests,
    }
    return render(request, 'dashboard.html', context)


@login_required
def profile_view(request, username=None):
    if username:
        profile_user = get_object_or_404(User, username=username)
    else:
        profile_user = request.user

    profile, _ = Profile.objects.get_or_create(user=profile_user)

    # Friend status
    friend_status = None
    if request.user != profile_user:
        try:
            fr = FriendRequest.objects.get(
                Q(sender=request.user, receiver=profile_user) |
                Q(sender=profile_user, receiver=request.user)
            )
            friend_status = fr.status if fr.sender == request.user else ('received_' + fr.status)
        except FriendRequest.DoesNotExist:
            friend_status = 'none'

    projects = Project.objects.filter(
        Q(owner=profile_user) | Q(members=profile_user)
    ).distinct()[:4]

    return render(request, 'users/profile.html', {
        'profile_user': profile_user,
        'profile': profile,
        'friend_status': friend_status,
        'projects': projects,
    })


@login_required
def edit_profile(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            # Update user fields
            request.user.first_name = request.POST.get('first_name', request.user.first_name)
            request.user.last_name = request.POST.get('last_name', request.user.last_name)
            request.user.email = request.POST.get('email', request.user.email)
            request.user.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = ProfileForm(instance=profile)
    return render(request, 'users/edit_profile.html', {'form': form})


# ===== PROJECTS =====

@login_required
def project_list(request):
    q = request.GET.get('q', '')
    status_filter = request.GET.get('status', '')
    projects = Project.objects.filter(
        Q(owner=request.user) | Q(members=request.user)
    ).distinct()

    if q:
        projects = projects.filter(name__icontains=q)
    if status_filter:
        projects = projects.filter(status=status_filter)

    projects = projects.order_by('-updated_at')
    return render(request, 'projects/list.html', {
        'projects': projects,
        'q': q,
        'status_filter': status_filter,
    })


@login_required
def project_create(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.owner = request.user
            project.save()
            form.save_m2m()
            messages.success(request, f'Project "{project.name}" created! 🎉')
            return redirect('project_detail', pk=project.pk)
    else:
        form = ProjectForm()
    return render(request, 'projects/form.html', {'form': form, 'action': 'Create'})


@login_required
def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    if request.user != project.owner and request.user not in project.members.all():
        messages.error(request, 'Access denied.')
        return redirect('project_list')

    tasks_by_status = {
        'todo': project.tasks.filter(status='todo').order_by('-priority'),
        'in_progress': project.tasks.filter(status='in_progress').order_by('-priority'),
        'review': project.tasks.filter(status='review').order_by('-priority'),
        'done': project.tasks.filter(status='done').order_by('-updated_at'),
    }

    return render(request, 'projects/detail.html', {
        'project': project,
        'tasks_by_status': tasks_by_status,
    })


@login_required
def project_edit(request, pk):
    project = get_object_or_404(Project, pk=pk, owner=request.user)
    if request.method == 'POST':
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            form.save()
            messages.success(request, 'Project updated!')
            return redirect('project_detail', pk=project.pk)
    else:
        form = ProjectForm(instance=project)
    return render(request, 'projects/form.html', {'form': form, 'action': 'Edit', 'project': project})


@login_required
def project_delete(request, pk):
    project = get_object_or_404(Project, pk=pk, owner=request.user)
    if request.method == 'POST':
        name = project.name
        project.delete()
        messages.success(request, f'Project "{name}" deleted.')
        return redirect('project_list')
    return render(request, 'projects/confirm_delete.html', {'project': project})


# ===== TASKS =====

@login_required
def task_create(request, project_pk):
    project = get_object_or_404(Project, pk=project_pk)
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.project = project
            task.created_by = request.user
            task.save()
            messages.success(request, f'Task "{task.title}" created!')
            return redirect('project_detail', pk=project.pk)
    else:
        form = TaskForm()
    return render(request, 'tasks/form.html', {'form': form, 'project': project, 'action': 'Create'})


@login_required
def task_detail(request, pk):
    task = get_object_or_404(Task, pk=pk)
    comment_form = CommentForm()

    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.task = task
            comment.author = request.user
            comment.save()
            messages.success(request, 'Comment added!')
            return redirect('task_detail', pk=task.pk)

    comments = task.comments.all().order_by('created_at')
    return render(request, 'tasks/detail.html', {
        'task': task,
        'comments': comments,
        'comment_form': comment_form,
    })


@login_required
def task_edit(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, 'Task updated!')
            return redirect('task_detail', pk=task.pk)
    else:
        form = TaskForm(instance=task)
    return render(request, 'tasks/form.html', {'form': form, 'project': task.project, 'action': 'Edit', 'task': task})


@login_required
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    project = task.project
    if request.method == 'POST':
        task.delete()
        messages.success(request, 'Task deleted.')
        return redirect('project_detail', pk=project.pk)
    return render(request, 'tasks/confirm_delete.html', {'task': task})


@login_required
def task_update_status(request, pk):
    task = get_object_or_404(Task, pk=pk)
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if new_status in dict(Task.STATUS_CHOICES):
            task.status = new_status
            task.save()
            return JsonResponse({'success': True, 'status': task.get_status_display()})
    return JsonResponse({'success': False})


@login_required
def my_tasks(request):
    tasks = Task.objects.filter(assigned_to=request.user).order_by('status', 'due_date')
    return render(request, 'tasks/my_tasks.html', {'tasks': tasks})


# ===== FRIENDS =====

@login_required
def user_list(request):
    q = request.GET.get('q', '')
    users = User.objects.exclude(pk=request.user.pk)
    if q:
        users = users.filter(
            Q(username__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q)
        )

    # Annotate friend status
    sent = FriendRequest.objects.filter(sender=request.user).values_list('receiver_id', 'status')
    received = FriendRequest.objects.filter(receiver=request.user).values_list('sender_id', 'status')
    sent_map = {uid: s for uid, s in sent}
    received_map = {uid: s for uid, s in received}

    user_data = []
    for u in users:
        if u.id in sent_map:
            status = 'sent_' + sent_map[u.id]
        elif u.id in received_map:
            status = 'received_' + received_map[u.id]
        else:
            status = 'none'
        profile, _ = Profile.objects.get_or_create(user=u)
        user_data.append({'user': u, 'status': status, 'profile': profile})

    return render(request, 'friends/user_list.html', {'user_data': user_data, 'q': q})


@login_required
def send_friend_request(request, user_id):
    receiver = get_object_or_404(User, pk=user_id)
    if receiver != request.user:
        FriendRequest.objects.get_or_create(sender=request.user, receiver=receiver)
        messages.success(request, f'Friend request sent to {receiver.username}!')
    return redirect(request.META.get('HTTP_REFERER', 'user_list'))


@login_required
def accept_friend_request(request, request_id):
    fr = get_object_or_404(FriendRequest, pk=request_id, receiver=request.user)
    fr.status = 'accepted'
    fr.save()
    messages.success(request, f'You are now friends with {fr.sender.username}!')
    return redirect(request.META.get('HTTP_REFERER', 'user_list'))


@login_required
def reject_friend_request(request, request_id):
    fr = get_object_or_404(FriendRequest, pk=request_id, receiver=request.user)
    fr.status = 'rejected'
    fr.save()
    return redirect(request.META.get('HTTP_REFERER', 'user_list'))


@login_required
def friend_requests(request):
    pending = FriendRequest.objects.filter(receiver=request.user, status='pending')
    return render(request, 'friends/requests.html', {'pending': pending})


@login_required
def friends_list(request):
    accepted = FriendRequest.objects.filter(
        Q(sender=request.user, status='accepted') |
        Q(receiver=request.user, status='accepted')
    )
    friends = []
    for fr in accepted:
        friend = fr.receiver if fr.sender == request.user else fr.sender
        profile, _ = Profile.objects.get_or_create(user=friend)
        friends.append({'user': friend, 'profile': profile})
    return render(request, 'friends/friends_list.html', {'friends': friends})
